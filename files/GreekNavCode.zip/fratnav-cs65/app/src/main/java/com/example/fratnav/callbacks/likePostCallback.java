package com.example.fratnav.callbacks;

public interface likePostCallback {

    void onCallback(int likes);
}

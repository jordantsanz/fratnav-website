package com.example.fratnav.callbacks;


import com.example.fratnav.models.House;

import java.util.ArrayList;

public interface getAllHousesCallback {
    void onCallback(ArrayList<House> houses);
}

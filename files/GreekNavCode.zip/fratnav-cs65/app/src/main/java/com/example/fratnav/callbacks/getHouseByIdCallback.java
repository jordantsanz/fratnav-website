package com.example.fratnav.callbacks;

import com.example.fratnav.models.House;

public interface getHouseByIdCallback {
    void onCallback(House house);
}

package com.example.fratnav.callbacks;

public interface createCallback {
    public void onCallback(boolean didFinish);
}

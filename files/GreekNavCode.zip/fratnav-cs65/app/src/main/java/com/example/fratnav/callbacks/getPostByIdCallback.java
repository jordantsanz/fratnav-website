package com.example.fratnav.callbacks;

import com.example.fratnav.models.Post;

public interface getPostByIdCallback {
    void onCallback(Post post);
}

package com.example.fratnav.callbacks;

import com.example.fratnav.models.User;

public interface getUserByIdCallback {
    void onCallback(User user);
}
